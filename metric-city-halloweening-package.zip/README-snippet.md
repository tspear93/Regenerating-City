## Rituals

- **[The Week of Halloweening — Governmental Doctrine](docs/week-of-halloweening.md)**  
  Annual civic ritual overseen by the Ministry of Temporal Harmony; replaces fear with transformation.

∞
