# Infinity-EOF Convention

Every file in this repository must end with an infinity symbol to signify
continuous regeneration: **∞**

- **Text files** (`.md`, `.txt`, `.json`, `.yml`, etc.): The last line must contain `∞`.
- **Binary files** (images, media, etc.): A sidecar marker named `<filename>.infinity` will be created containing `∞` so we never corrupt the binary.
- A **pre-commit hook** enforces this rule locally.

## Setup

```bash
git config core.hooksPath .githooks
```

This will activate the included `pre-commit` hook.

## Manual check

```bash
python3 scripts/ensure_infinity_eof.py <files...>
```

∞


## Core Metrics Scope

This convention applies **only** to files designated as *Core Metrics* in `.core-metrics.json`:
```json
{
  "core_patterns": [
    "docs/**",
    "INFINITY-CONVENTION.md"
  ]
}
```
Edit this file to control which artifacts are required to end with **∞**.
