#!/usr/bin/env python3
import sys, json, fnmatch, argparse
from pathlib import Path

INFINITY = "∞\n"
TEXT_EXTS = {".md",".mdx",".txt",".json",".yml",".yaml",".toml",".py",".js",".ts",".tsx",".css",".scss",".html",".xml",".csv"}
CFG_PATH = Path(".core-metrics.json")

def is_text_file(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTS

def load_core_patterns():
    if CFG_PATH.exists():
        try:
            data = json.loads(CFG_PATH.read_text(encoding="utf-8"))
            pats = data.get("core_patterns", [])
            return [p for p in pats if isinstance(p, str)]
        except Exception:
            pass
    return ["docs/week-of-halloweening.md", "INFINITY-CONVENTION.md"]

def matches_core(path: Path, patterns):
    s = str(path).replace("\\", "/")
    for pat in patterns:
        if fnmatch.fnmatch(s, pat):
            return True
    return False

def process(paths, check_only=False):
    core_patterns = load_core_patterns()
    changed = []
    for p in paths:
        path = Path(p)
        if not path.exists() or not path.is_file():
            continue
        if not matches_core(path, core_patterns):
            continue
        if is_text_file(path):
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if not content.rstrip().endswith("∞"):
                if check_only:
                    changed.append(str(path))
                else:
                    content = content.rstrip() + "\n\n" + INFINITY
                    path.write_text(content, encoding="utf-8")
                    changed.append(str(path))
        else:
            # Binary/core: sidecar marker
            marker = Path(str(path) + ".infinity")
            if not marker.exists():
                if check_only:
                    changed.append(str(marker))
                else:
                    marker.write_text("∞\n", encoding="utf-8")
                    changed.append(str(marker))
    return changed

def main():
    parser = argparse.ArgumentParser(description="Ensure infinity symbol at EOF for Core Metrics files.")
    parser.add_argument("--check", action="store_true", help="Do not write changes; exit non-zero if updates needed.")
    parser.add_argument("paths", nargs="*", help="Files to check/update. If omitted, scans repo for core files.")
    args = parser.parse_args()

    paths = args.paths
    if not paths:
        # scan repo for core files
        patterns = load_core_patterns()
        paths = []
        for p in Path(".").rglob("*"):
            if p.is_file() and matches_core(p, patterns):
                paths.append(str(p))

    changed = process(paths, check_only=args.check)
    if changed:
        print("∞ Enforcement needed for the following artifacts:")
        for c in changed:
            print(" -", c)
        if args.check:
            print("\nTip: run without --check to auto-fix locally:")
            print("  python3 scripts/ensure_infinity_eof.py", *paths)
            return 1
        else:
            print("\nApplied ∞ to the artifacts above.")
    else:
        print("All Core Metrics files comply with ∞.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
